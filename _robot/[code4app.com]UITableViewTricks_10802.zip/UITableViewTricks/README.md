UITableViewTricks
=================

Simple UITableView tricks with focus on UITableViewCell Layout

Check the for the description at my blog https://iphone2020.wordpress.com/2012/06/10/uitableview-tricks/

I hope you don't mind sending an appreciation e-mail to bharath2020@gmail.com if you plan to use this control in your applications. :)

This Control also appeared in

http://www.maniacdev.com

http://mobiledevelopertips.com/

Thanks for the post guys.