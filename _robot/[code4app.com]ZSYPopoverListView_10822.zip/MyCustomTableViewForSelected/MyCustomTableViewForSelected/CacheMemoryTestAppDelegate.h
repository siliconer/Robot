//
//  CacheMemoryTestAppDelegate.h
//  MyCustomTableViewForSelected
//
//  Created by Zhu Shouyu on 6/2/13.
//  Copyright (c) 2013 zhu shouyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CacheMemoryTestViewController;

@interface CacheMemoryTestAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CacheMemoryTestViewController *viewController;

@end
