gcc -I/opt/local/include/gphoto2 -L/opt/local/lib -o dsrl-stream dsrl-stream.c -lgphoto2
