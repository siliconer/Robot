gcc -o dsrl-stream dsrl-stream.c -lgphoto2
