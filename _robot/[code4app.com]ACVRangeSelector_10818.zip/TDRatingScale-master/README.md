TDRatingScale
=============

The TDRatingScale is similar to regular UISlider except that it has some best custom graphics which is more intuitive.The purpose of this custom slider is to provide mechanism for getting input from the user that represents a range from the UI point of view, this control provides a best enhancements and highly customizable UI components that can be easily matched to any graphic theme,Its a complete package of custom entity.


--------------------------------------------------------------
HOW TO USE IT IN YOUR CODE
--------------------------------------------------------------

1.Copy and Paste "TDRatingScale" folder in your project and Also add them to your project by right clicking your project in XCode and choose "Add files to your project".Note "TDRatingScale" folder can be found under TDRatingControl > "TDRatingScale" in TDRatingScale Project.

2.Add QuartzCore framework to your project

3.Add TDRatingViewDelegate delegate in your .h file

4.Then you can customize the TDRatingScale as per your needs
