//
//  M13InfiniteTabBarRequiresAttentionBackgroundView.m
//  M13InfiniteTabBar
//
//  Created by Brandon McQuilkin on 1/17/14.
//  Copyright (c) 2014 Brandon McQuilkin. All rights reserved.
//

#import "M13InfiniteTabBarRequiresAttentionBackgroundView.h"

@implementation M13InfiniteTabBarRequiresAttentionBackgroundView

- (void)showAnimationOnLeftEdgeWithImportanceLevel:(NSInteger)importanceLevel
{
    
}

- (void)showAnimationOnRightEdgeWithImportanceLevel:(NSInteger)importanceLevel
{
    
}

@end
