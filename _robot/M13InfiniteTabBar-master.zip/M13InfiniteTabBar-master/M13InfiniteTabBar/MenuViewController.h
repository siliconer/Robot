//
//  MenuViewController.h
//  M13InfiniteTabBar
//
//  Created by Brandon McQuilkin on 3/2/14.
//  Copyright (c) 2014 Brandon McQuilkin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "M13InfiniteTabBarController.h"

@interface MenuViewController : UITableViewController <M13InfiniteTabBarControllerDelegate>

@end
