//
//  CustomNavigationController.h
//  M13InfiniteTabBar
//
//  Created by Brandon McQuilkin on 3/4/14.
//  Copyright (c) 2014 Brandon McQuilkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavigationController : UINavigationController

@end
