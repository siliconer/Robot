//
//  MCSDemoXibFishEyeViewItem.h
//  FishEyeDemo
//
//  Created by Bartosz Ciechanowski on 9/3/13.
//  Copyright (c) 2013 Macoscope. All rights reserved.
//

#import "MCSFishEyeViewItem.h"

@interface MCSDemoXibFishEyeViewItem : MCSFishEyeViewItem

@property (weak, nonatomic) IBOutlet UILabel *label;

@end
