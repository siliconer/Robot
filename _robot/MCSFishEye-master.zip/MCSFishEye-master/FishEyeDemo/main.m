//
//  main.m
//  FishEyeDemo
//
//  Created by Bartosz Ciechanowski on 8/29/13.
//  Copyright (c) 2013 Macoscope. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MCSAppDelegate.h"

int main(int argc, char * argv[])
{
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass([MCSAppDelegate class]));
  }
}
