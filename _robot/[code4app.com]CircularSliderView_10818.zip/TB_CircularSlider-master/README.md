TB_CircularSlider
=================

This is the code for the tutorial "How to create a custom control in iOS" from http://www.thinkandbuild.it.

In this tutorial I show how to create a custom control as subclass of UIControl and I draw the 99% of the component using Core Graphics. 

Here a preview of the control built in this tutorial:

![A preview of this control](http://www.thinkandbuild.it/wp-content/uploads/2013/02/slider_preview_phone.png)
