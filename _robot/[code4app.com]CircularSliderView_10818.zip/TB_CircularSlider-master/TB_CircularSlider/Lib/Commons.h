//
//  Commons.h
//  TB_CircularSlider
//
//  Created by Yari Dareglia on 1/12/13.
//  Copyright (c) 2013 Yari Dareglia. All rights reserved.
//

#ifndef TB_CircularSlider_Commons_h
#define TB_CircularSlider_Commons_h

#define TB_HANDLEIMAGE          @"handle.jpeg"
#define TB_ACTIVEHANDLEIMAGE    @"active_handle"

#define TB_HANDLESIZE           40


#endif
