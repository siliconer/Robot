#import <UIKit/UIKit.h>
#import "RNGridMenu.h"

@interface RNViewController : UIViewController <RNGridMenuDelegate>

@end
