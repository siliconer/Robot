//
//  LeveyPopListViewCell.h
//  LeveyPopListViewDemo
//
//  Created by Levey on 2/21/12.
//  Copyright (c) 2012 Levey. All rights reserved.
//

@interface LeveyPopListViewCell : UITableViewCell

@end
