SoundMixer-Fader-UI
===================

Just for practise, A control for sound mixer board UI. The control is customised UISlider transformed to vertical. The value is getting displayed in UILabel with glowing text