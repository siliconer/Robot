//
//  ACPScrollMenuTests.h
//  ACPScrollMenuTests
//
//  Created by Antonio Casero Palmero on 8/4/13.
//  Copyright (c) 2013 ACP. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ACPScrollMenuTests : SenTestCase

@end
