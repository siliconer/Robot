//
//  ViewController.h
//  InfiniteScrollPickerExample
//
//  Created by Philip Yu on 6/6/13.
//  Copyright (c) 2013 Philip Yu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfiniteScrollPicker.h"

@interface ViewController : UIViewController

@end
